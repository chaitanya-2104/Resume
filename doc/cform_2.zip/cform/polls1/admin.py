from django.contrib import admin

# Register your models here.
from .models import Qualification1


# Register your models here.
@admin.register( Qualification1)

class  QualificationModelAdmin(admin.ModelAdmin):
    list_display=['id','Qualification1','University1','Institution1','Year_of_passing1','Percentag1']