from django.db import models

# Create your models here.
class  Qualification1(models.Model):
    Qualification1=models.CharField(max_length=100)
    University1=models.CharField(max_length=100)
    Institution1=models.CharField(max_length=100)
    Year_of_passing1=models.PositiveIntegerField()
    Percentag1=models.CharField(max_length=100)