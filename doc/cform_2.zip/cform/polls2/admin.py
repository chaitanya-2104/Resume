from django.contrib import admin

# Register your models here.
from .models import Qualification2


# Register your models here.
@admin.register( Qualification2)

class  QualificationModelAdmin(admin.ModelAdmin):
    list_display=['id','Qualification2','University2','Institution2','Year_of_passing2','Percentag2']