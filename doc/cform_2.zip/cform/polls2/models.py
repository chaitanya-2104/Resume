from django.db import models

# Create your models here.
from django.db import models

# Create your models here.
class  Qualification2(models.Model):
    Qualification2=models.CharField(max_length=100)
    University2=models.CharField(max_length=100)
    Institution2=models.CharField(max_length=100)
    Year_of_passing2=models.PositiveIntegerField()
    Percentag2=models.CharField(max_length=100)