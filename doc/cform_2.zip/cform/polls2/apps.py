from django.apps import AppConfig


class Polls2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'polls2'
