from django.db import models

# Create your models here.
class  Qualification3(models.Model):
    Qualification3=models.CharField(max_length=100)
    University3=models.CharField(max_length=100)
    Institution3=models.CharField(max_length=100)
    Year_of_passing3=models.PositiveIntegerField()
    Percentag3=models.CharField(max_length=100)