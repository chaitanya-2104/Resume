from django.contrib import admin

# Register your models here.
from .models import Qualification3


# Register your models here.
admin.site.register( Qualification3)

class  QualificationModelAdmin(admin.ModelAdmin):
    list_display=['id','Qualification3','University3','Institution3','Year_of_passing3','Percentag3']