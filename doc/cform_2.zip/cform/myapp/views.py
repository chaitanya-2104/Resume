from django.shortcuts import render
from .forms import StudentForms,QualificationForms,QualificationForms1,QualificationForms2,QualificationForms3
# Create your views here.
from myapp.models import Form
from polls.models import Qualification
from polls1.models import Qualification1
from polls2.models import Qualification2
from polls3.models import Qualification3

from django.views import View

class HomeView(View):
    def get(self,request):
        form =StudentForms(prefix="sud")
        form1 =QualificationForms(prefix="Qu")
        form2 =QualificationForms1(prefix="Qp")
        form3 =QualificationForms2(prefix="Ql")
        form4 =QualificationForms3(prefix="Qiu")
       
        candidates =Form.objects.all()
        #candidates1=Qualification.objects.all()
        return render(request,'myapp/home.html',{'candidates':candidates,'form':form,'form1':form1,'form2':form2,'form3':form3,'form4':form4})
    
    def post(self,request):
        form = StudentForms(request.POST,request.FILES,prefix="sud")
        form1=QualificationForms(request.POST,prefix="Qu")
        form2=QualificationForms1(request.POST,prefix="Q")
        form3=QualificationForms2(request.POST,prefix="Qui")
        form4=QualificationForms3(request.POST,prefix="Qj")
     
        if form.is_valid():
            form.save()
        if form1.is_valid():
            form1.save()
        if form2.is_valid():
            form2.save()
        if form3.is_valid():
            form3.save()
        if form4.is_valid():
            form4.save()


        return render(request,'myapp/home.html',{'form':form,'form1':form1,'form2':form2,'form3':form3,'form4':form4})
def Show(request):
    
    candidates =Form.objects.all()
    candidates1=Qualification.objects.all() 
    candidates2=Qualification1.objects.all() 
    candidates3=Qualification2.objects.all() 
    candidates4=Qualification3.objects.all() 
    
    
    return render(request,'myapp/List.html',{'candidate1':candidates1,'candidates':candidates,'candidate2':candidates2,'candidate4':candidates4,'candidate4':candidates4})
class CandidatesView(View):
    def get(self,request,pk):
    
        candidates =Form.objects.get(pk=pk)
        candidates1=Qualification.objects.get(pk=pk)
        candidates2=Qualification1.objects.get(pk=pk) 
        candidates3=Qualification2.objects.get(pk=pk)
        candidates4=Qualification3.objects.get(pk=pk)
      
    
        return render(request,'myapp/candidate.html',{'candidate1':candidates1,'candidates':candidates,'candidate2':candidates2,'candidate3':candidates3,'candidate4':candidates4})
   