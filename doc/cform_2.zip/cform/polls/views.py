from django.shortcuts import render
#from .forms import QualificationForms
# Create your views here.
#from .models import From
#from django.views import View

#class HomeView(View):
 ##      fo =QualificationForms()
   #     return render(request,'polls/home.html',{'student':fo})
#def post(self,request):
 ##      if form.is_valid():
   #         form.save()
    #        return render(request,'polls/home.html',{'form':form})



