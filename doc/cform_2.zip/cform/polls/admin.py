from django.contrib import admin

from .models import Qualification


# Register your models here.
admin.site.register( Qualification)

class  QualificationModelAdmin(admin.ModelAdmin):
    list_display=['id','Qualification','University','Institution','Year_of_passing','Percentag']