from  django import forms
#from .models import Qualification
#class QualificationForms(forms.ModelForm):

 #   class Meta:
  #      model = Qualification
   #     fields = ['Qualification','University','Institution','Year_of_passing','Percentag']