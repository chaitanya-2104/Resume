from django.db import models

# Create your models here.
class  Qualification(models.Model):
    Qualification=models.CharField(max_length=100)
    University=models.CharField(max_length=100)
    Institution=models.CharField(max_length=100)
    Year_of_passing=models.PositiveIntegerField()
    Percentag=models.CharField(max_length=100)