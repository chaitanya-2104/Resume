package com.details;

public class User 
{
	
	private String EName;
	private String pass;
	private String Email;
	
	
	public User() 
	{
		
}
	
	
	





	public String getEName() {
		return EName;
	}





	public void setName(String name) {
		EName = name;
	}





	public String getPass() {
		return pass;
	}





	public void setPass(String pass) {
		this.pass = pass;
	}





	public String getEmail() {
		return Email;
	}





	public void setEmail(String email) {
		Email = email;
	}





	

	
}
